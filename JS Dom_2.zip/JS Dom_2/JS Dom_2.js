/*function celsiustilfarah(cel) {
  const cTemperatur = cel;
  const celsiustilfarah = cTemperatur * 9 / 5 + 32;
  const message = `${cTemperatur}\xB0C is ${celsiustilfarah} \xB0F.`;
    document.write(message);
}


function farahtilcelsius(fah) {
  const fTemperatur = fah;
  const farahtilcelsius = (fTemperatur - 32) * 5 / 9;
  const message = `${fTemperatur}\xB0F is ${farahtilcelsius}\xB0C.`;
    document.write(message);
} 
celsiustilfarah(50);
farahtilcelsius(35);
*/

document.getElementById('skrivUtNoe').addEventListener('click', function () 
{
  let tall1 = document.getElementById("tallern1").value;
  let tall2 = document.getElementById("tallern2").value;
  
  const num = Math.ceil(Math.random() * let tall1, let tall2);
  document.write(num);

  if (tall1 < tall2) {
      document.getElementById("resultat").innerHTML = "tall 1 er mindre enn tall 2";
  } else if (tall1 > tall2) {
    
      document.getElementById("resultat").innerHTML = "tall 1 er større enn tall 2";
  } else {

      document.getElementById("resultat").innerHTML = "De er helt like";
  }
  if (gnum == num) console.log('Passer Sammen');
  else console.log('Passer ikke sammen, nummeret var ' + gnum);
});